package ass4;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class Boggle {
    private static final Random random = new Random();
    private static final String ALPHABET = "abcdefghijklmnopqrstuvwxyz";
    private static final double[] FREQUENCIES = {
            0.08167, 0.01492, 0.02782, 0.04253, 0.12703, 0.02228,
            0.02015, 0.06094, 0.06966, 0.00153, 0.00772, 0.04025,
            0.02406, 0.06749, 0.07507, 0.01929, 0.00095, 0.05987,
            0.06327, 0.09056, 0.02758, 0.00978, 0.02360, 0.00150,
            0.01974, 0.00074
    };

    public static String[][] board;
    public static Dictionary dictionary;

    public Boggle(int N) {
        initializeRandomBoard(N);
    }

    public Boggle(String[][] board) {
        this.board = new String[board.length][board.length];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board.length; j++) {
                this.board[i][j] = board[i][j].toLowerCase();
            }
        }
    }

    public Boggle(String[] dice) {
        shakeDice(dice, random);
    }

    public Boggle(String filename) {
        readBoardFromFile(filename);
    }

    public Boggle(String[] dice, long seed) {
        shakeDice(dice, new Random(seed));
    }

    private void initializeRandomBoard(int N) {
        board = new String[N][N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                board[i][j] = getRandomLetter().toLowerCase();
            }
        }
    }

    private String getRandomLetter() {
        double randomValue = random.nextDouble();
        double chance = 0;

        for (int i = 0; i < ALPHABET.length(); i++) {
            chance += FREQUENCIES[i];
            if (randomValue <= chance) {
                return String.valueOf(ALPHABET.charAt(i));
            }
        }

        return "";
    }

    private void shakeDice(String[] dice, Random rand) {
        shuffleArray(dice, rand);

        int rows = (int) Math.sqrt(dice.length);
        board = new String[rows][rows];

        for (int i = 0; i <dice.length; i++) {
            int row = i / rows;
            int col = i % rows;
            int faceIndex = rand.nextInt(dice[i].length());
            board[row][col] = String.valueOf(dice[i].charAt(faceIndex)).toLowerCase();
        }

//        int faceIndex = rand.nextInt(dice.length);
//        for (int i = 0; i < rows; i++) {
//            for (int j = 0; j < rows; j++) {
//                board[i][j] = String.valueOf(dice[faceIndex].charAt(rand.nextInt(6))).toLowerCase();
//                faceIndex++;
//            }
//        }
    }

//    private static void shuffleArray(String[] array, Random random) {
//        for (int i = array.length - 1; i > 0; i--) {
//            int index = random.nextInt(i + 1);
//
//            String temp = array[i];
//            array[i] = array[index];
//            array[index] = temp;
//        }
//    }

    private void shuffleArray(String[] array, Random rand) {
        for (int i = 0; i <= array.length - 2; i++) {
            int j = rand.nextInt(array.length - i) + i;
            String temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
    }

    private void readBoardFromFile(String filename) {
        try {
            Scanner sc = new Scanner(new File(filename));
            String[] dimensions = sc.nextLine().trim().split(" ");
            int rows = Integer.parseInt(dimensions[0]);
            int cols = Integer.parseInt(dimensions[1]);

            board = new String[rows][cols];
            for (int i = 0; i < rows; i++) {
                String line = sc.nextLine().trim().toLowerCase();
                String[] row = line.split(" ");
                board[i] = row;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean matchWord(String word) {
        clearHighlights();
        word = word.toLowerCase();
        boolean[][] visited = new boolean[board.length][board[0].length];
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (matchWordRecursive(word, i, j, 0, visited)) {
//                    highlightWord(word, i, j);
                    return true;
                }
            }
        }

        clearHighlights();
        return false;
    }

    private boolean matchWordRecursive(String word, int row, int col, int index, boolean[][] visited) {
        if (index == word.length()) {
            return true;
        }

        if (row < 0 || col < 0 || row >= board.length || col >= board[0].length || visited[row][col]) {
            return false;
        }

        if (board[row][col].equals(String.valueOf(word.charAt(index)))) {
            visited[row][col] = true;
            board[row][col] = board[row][col].toUpperCase();
            if (matchWordRecursive(word, row - 1, col - 1, index + 1, visited) ||
                    matchWordRecursive(word, row - 1, col, index + 1, visited) ||
                    matchWordRecursive(word, row - 1, col + 1, index + 1, visited) ||
                    matchWordRecursive(word, row, col - 1, index + 1, visited) ||
                    matchWordRecursive(word, row, col + 1, index + 1, visited) ||
                    matchWordRecursive(word, row + 1, col - 1, index + 1, visited) ||
                    matchWordRecursive(word, row + 1, col, index + 1, visited) ||
                    matchWordRecursive(word, row + 1, col + 1, index + 1, visited)) {
                return true;
            }

            board[row][col] = board[row][col].toLowerCase();
            visited[row][col] = false;
        }

        return false;
    }

//    private void highlightWord(String word, int startRow, int startCol) {
//        int index = 0;
//        for (int i = startRow; i < startRow + word.length(); i++) {
//            for (int j = startCol; j < startCol + word.length(); j++) {
//                board[i][j] = String.valueOf(word.charAt(index)).toUpperCase();
//                index++;
//            }
//        }
//    }

    private void clearHighlights() {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                board[i][j] = board[i][j].toLowerCase();
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (String[] row : board) {
            for (String letter : row) {
                result.append(letter.equalsIgnoreCase("Qu") ? "Q" : letter).append(" ");
            }
            result.append(System.lineSeparator());
        }

        return result.toString();
    }

    public static List<String> getAllValidWords(String dictionaryName, String boardName) {
        Boggle boggle = new Boggle(boardName);
        Dictionary dictionary = new Dictionary(dictionaryName);
        List<String> validWords = new ArrayList<>();

        for (int i = 0; i < boggle.board.length; i++) {
            for (int j = 0; j < boggle.board[0].length; j++) {
                getAllValidWordsRecursive("", i, j, boggle.board, dictionary, validWords, new boolean[boggle.board.length][boggle.board[0].length]);
            }
        }

        Collections.sort(validWords);
        return validWords;
    }

    public static List<String> getAllValidWords() {
        if (board == null || dictionary == null) {
            System.out.println("Board or dictionary is null.");
            return new ArrayList<>();
        }

        List<String> validWords = new ArrayList<>();
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                getAllValidWordsRecursive("", i, j, board, dictionary, validWords, new boolean[board.length][board[0].length]);
            }
        }

        return validWords;
    }

    private static void getAllValidWordsRecursive(String currentWord, int row, int col, String[][] board, Dictionary dictionary, List<String> validWords, boolean[][] visited) {
        if (row < 0 || col < 0 || row >= board.length || col >= board[0].length || visited[row][col]) {
            return;
        }

        currentWord += board[row][col];
        visited[row][col] = true;

        if (dictionary.containsWord(currentWord) && currentWord.length() >= 3 && !validWords.contains(currentWord)) {
//        if (dictionary.containsWord(currentWord) && !validWords.contains(currentWord)) {
            validWords.add(currentWord);
        }

        getAllValidWordsRecursive(currentWord, row - 1, col - 1, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row - 1, col, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row - 1, col + 1, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row, col - 1, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row, col + 1, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row + 1, col - 1, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row + 1, col, board, dictionary, validWords, visited);
        getAllValidWordsRecursive(currentWord, row + 1, col + 1, board, dictionary, validWords, visited);

        visited[row][col] = false;
    }

    private static int calculateWordLength(String word) {
        String str = word.replaceAll("qu", "q");
        return str.length();
    }

    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println("Usage: java Boggle <board_file> <dictionary_file>");
            return;
        }

        String boardFile = args[0];
        String dictionaryFile = args[1];

        Boggle boggle = new Boggle(boardFile);
        boggle.dictionary = new Dictionary(dictionaryFile);

        System.out.println("Current Board:\n" + boggle);

        int userScore = 0;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.print("Enter a word (or type 'exit' to end the game): ");
            String word = scanner.nextLine().trim().toLowerCase();
            if (word.equals("exit")) {
                break;
            }

            if (boggle.matchWord(word) && dictionary.containsWord(word)) {
                int wordLength = calculateWordLength(word);
                userScore += Math.max(0, wordLength - 2); // Calculate score based on word length
                System.out.println("Valid word! Your score: " + userScore);
                System.out.println("Updated Board:\n" + boggle);
            } else {
                System.out.println("Invalid word. Try again!");
            }
        } while (true);

        System.out.print("Do you want to find the maximum number of possible words? (yes/no): ");
        String response = scanner.nextLine().trim().toLowerCase();
        if (response.equals("yes")) {
            int maxPossibleWords = getAllValidWords().size();
            System.out.println("Maximum number of possible words: " + maxPossibleWords);
        }

        System.out.println("Game Over!");
    }
}
