package ass4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Dictionary {
    private Set<String> words;

    public Dictionary(String filename) {
        words = new HashSet<>();
        loadDictionary(filename);
    }

    private void loadDictionary(String filename) {
        try {
            Scanner sc = new Scanner(new File(filename));
            while (sc.hasNextLine()) {
                String word = sc.nextLine().trim();
                if (word.length() == 0) {
                    continue;
                }

                words.add(word.toLowerCase());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public boolean containsWord(String word) {
        return words.contains(word.toLowerCase());
    }
}

